import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { DynamoDBDocumentClient, PutCommand } from "@aws-sdk/lib-dynamodb";

const client = new DynamoDBClient({});
const docClient = DynamoDBDocumentClient.from(client);

export const handler = async (event) => {
  try {
    // 1. Parse the incoming data
    // API Gateway sends the data as a string inside 'body'
    let data;
    if (event.body) {
        data = JSON.parse(event.body);
    } else {
        data = event;
    }

    // 2. Prepare the item for DynamoDB
    const command = new PutCommand({
      TableName: "IncidentReports", // Must match Member 3's table name exactly
      Item: {
        IncidentID: data.IncidentID,
        Location: data.Location,
        IncidentType: data.IncidentType,
        Description: data.Description,
        Timestamp: data.Timestamp,
        Status: "New" 
      },
    });

    // 3. Save to DynamoDB
    await docClient.send(command);

    // 4. Return Success to the Website
    return {
      statusCode: 200,
      headers: {
          "Access-Control-Allow-Origin": "*", 
          "Access-Control-Allow-Methods": "POST"
      },
      body: JSON.stringify({ message: "Saved to DynamoDB!" }),
    };

  } catch (error) {
    console.error("Error saving to DynamoDB:", error);
    return {
      statusCode: 500,
      headers: {
          "Access-Control-Allow-Origin": "*",
      },
      body: JSON.stringify({ error: error.message }),
    };
  }
};